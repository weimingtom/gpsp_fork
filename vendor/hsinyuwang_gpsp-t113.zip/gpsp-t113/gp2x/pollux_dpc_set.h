#ifdef __cplusplus
extern "C"
{
#endif

int pollux_dpc_set(volatile unsigned short *memregs, const char *str);

#ifdef __cplusplus
}
#endif
