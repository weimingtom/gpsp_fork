gpsp for gameshell build version

